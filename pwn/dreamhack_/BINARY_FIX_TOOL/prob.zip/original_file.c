//gcc -o original_file.c original_file

#include <stdio.h>

int main(){
	printf("Hello world!");
}
