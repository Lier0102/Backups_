#!/bin/sh
/usr/bin/mongod & sleep 6 && kill %1